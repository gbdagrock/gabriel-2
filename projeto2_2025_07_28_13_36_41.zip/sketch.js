function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  fill("black");
  textAlign(CENTER, CENTER)

 textSize(28);

 let palavra = "Gabriel Amaral Candido";
 let maximo = width;
 let quantidade = map(mouseX, 0, width, 1, palavra.length)
 let parcial = palavra.substring(0, quantidade);
 text(parcial, 250, 200);


}